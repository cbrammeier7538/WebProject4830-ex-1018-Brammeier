package p3.csvfilesource;

public class MySum {
   private int input1;
   private int input2;

   public MySum(int input1, int input2) {
      this.input1 = input1;
      this.input2 = input2;
   }

   public int sum() {
      return this.input1 + this.input2;
   }
}
